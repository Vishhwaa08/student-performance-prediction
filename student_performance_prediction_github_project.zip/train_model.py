from pathlib import Path
import json, joblib
from model_utils import load_data,train_model
ROOT=Path(__file__).parent
def main():
    data=load_data(ROOT/"student_performance.csv"); model,metrics=train_model(data)
    folder=ROOT/"models"; folder.mkdir(exist_ok=True)
    joblib.dump({"model":model,"metrics":metrics},folder/"student_model.joblib")
    (folder/"metrics.json").write_text(json.dumps(metrics,indent=2),encoding="utf-8")
    print(f"Rows: {len(data)} | MAE: {metrics['mae']:.2f} | R2: {metrics['r2']:.3f}")
if __name__=="__main__": main()
