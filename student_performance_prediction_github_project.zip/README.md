# Student Performance Prediction System

A Python + Machine Learning project that estimates a student's final score from study habits and academic indicators. Built with Streamlit, Pandas, scikit-learn and Matplotlib.

## Features
- Predict an estimated score (0–100).
- Categorize estimates: Excellent, Good, Needs improvement, At risk.
- Display MAE and R² model metrics.
- Explore dataset charts and preview records.
- Download an individual prediction as CSV.
- Train model separately with `train_model.py`.

## Project structure
```text
student_performance_prediction/
├── app.py
├── model_utils.py
├── train_model.py
├── student_performance.csv
├── requirements.txt
├── README.md
├── .gitignore
└── models/   (created after training; model file is gitignored)
```

## Setup (VS Code / terminal)
```bash
git clone https://github.com/YOUR-USERNAME/student-performance-prediction.git
cd student-performance-prediction
python -m venv .venv
```
Windows activation: `.venv\\Scripts\\activate`
macOS/Linux activation: `source .venv/bin/activate`

Install packages:
```bash
pip install -r requirements.txt
```

Train the model (optional; app can train automatically):
```bash
python train_model.py
```

Run:
```bash
streamlit run app.py
```
Open the local URL printed in the terminal (usually http://localhost:8501).

## Dataset columns
| Column | Meaning |
|---|---|
| study_hours | Average daily study hours |
| attendance | Attendance percentage |
| previous_score | Previous exam score (0–100) |
| assignments_completed | Completed assignments (0–10) |
| sleep_hours | Average daily sleep hours |
| class_participation | Participation rating (1–5) |
| final_score | Target score (0–100) |

## Dataset and responsible-use notice
The included CSV contains **synthetic demonstration data**, not actual student records. Model metrics on synthetic data do not demonstrate real-world accuracy. For real evaluation, use representative, consented and anonymized data, check for bias and data leakage, and test on students not used for training.

This project is for educational demonstration. Do not use predictions as the sole basis for grading, admissions, discipline, or other high-impact decisions.

## Upload to GitHub
Create an empty repository on GitHub, then run:
```bash
git init
git add .
git commit -m "Add student performance prediction project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-performance-prediction.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username.

## Future enhancements
- Upload a custom CSV dataset.
- Compare Linear Regression, Random Forest and Gradient Boosting.
- Add feature-importance explanations.
- Add model validation and fairness checks.
