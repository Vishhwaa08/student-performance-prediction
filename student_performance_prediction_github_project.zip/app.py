from pathlib import Path
import streamlit as st, pandas as pd, matplotlib.pyplot as plt
from model_utils import load_data,load_or_train_model,predict_score,performance_category,TARGET
st.set_page_config(page_title="Student Performance Predictor",page_icon="🎓",layout="wide")
st.title("🎓 Student Performance Prediction")
st.write("Estimate a student's final score from academic and study-habit information.")
ROOT=Path(__file__).parent
@st.cache_resource
def get_model(): return load_or_train_model(ROOT/"student_performance.csv",ROOT/"models"/"student_model.joblib")
try:
    model,metrics=get_model(); data=load_data(ROOT/"student_performance.csv")
except Exception as e:
    st.error(f"Unable to load project data/model: {e}"); st.stop()
with st.sidebar:
    st.header("Model information"); st.metric("Training rows",len(data))
    st.metric("Test R²",f"{metrics['r2']:.3f}"); st.metric("Test MAE",f"{metrics['mae']:.1f} marks")
    st.caption("Metrics use a held-out split of the included illustrative dataset.")
c1,c2=st.columns(2)
with c1:
    st.subheader("Student details")
    with st.form("predict"):
        hours=st.slider("Daily study hours",.5,12.,3.,.5)
        attendance=st.slider("Attendance (%)",0,100,85)
        previous=st.slider("Previous exam score",0,100,70)
        assignments=st.slider("Assignments completed (out of 10)",0,10,8)
        sleep=st.slider("Average sleep hours",0.,12.,7.,.5)
        participation=st.slider("Class participation (1=low, 5=high)",1,5,3)
        go=st.form_submit_button("Predict performance",type="primary")
    if go:
        values={"study_hours":hours,"attendance":attendance,"previous_score":previous,"assignments_completed":assignments,"sleep_hours":sleep,"class_participation":participation}
        st.session_state["prediction"]=(predict_score(model,values),values)
with c2:
    st.subheader("Prediction result")
    if "prediction" in st.session_state:
        s,v=st.session_state["prediction"]; st.metric("Estimated final score",f"{s:.1f} / 100")
        st.success(f"Predicted category: **{performance_category(s)}**"); st.progress(int(round(s)))
        st.caption("An estimate, not a guaranteed result or official grade.")
        result=pd.DataFrame([{**v,"predicted_final_score":round(s,1),"category":performance_category(s)}])
        st.download_button("Download prediction CSV",result.to_csv(index=False),"student_prediction.csv","text/csv")
    else: st.info("Enter details and click Predict performance.")
st.divider(); st.subheader("Explore sample dataset")
x,y=st.columns(2)
with x:
    fig,ax=plt.subplots(); ax.scatter(data.study_hours,data[TARGET],alpha=.55)
    ax.set(xlabel="Daily study hours",ylabel="Final score",title="Study hours vs final score")
    st.pyplot(fig); plt.close(fig)
with y:
    fig,ax=plt.subplots(); ax.hist(data[TARGET],bins=15)
    ax.set(xlabel="Final score",ylabel="Number of students",title="Final score distribution")
    st.pyplot(fig); plt.close(fig)
with st.expander("Preview sample data"):
    st.dataframe(data.head(30),use_container_width=True)
    st.caption("CSV data is synthetic demonstration data, not real student records.")
