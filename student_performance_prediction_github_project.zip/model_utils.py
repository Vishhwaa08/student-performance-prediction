from pathlib import Path
import joblib, pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
FEATURES=["study_hours","attendance","previous_score","assignments_completed","sleep_hours","class_participation"]
TARGET="final_score"
def load_data(path):
    d=pd.read_csv(path); missing=[c for c in FEATURES+[TARGET] if c not in d]
    if missing: raise ValueError(f"Missing columns: {missing}")
    d=d[FEATURES+[TARGET]].dropna()
    if d.empty: raise ValueError("Dataset has no complete rows")
    return d
def train_model(d):
    xtr,xte,ytr,yte=train_test_split(d[FEATURES],d[TARGET],test_size=.2,random_state=42)
    m=RandomForestRegressor(n_estimators=250,max_depth=10,min_samples_leaf=2,random_state=42,n_jobs=-1)
    m.fit(xtr,ytr); pred=m.predict(xte)
    return m,{"mae":float(mean_absolute_error(yte,pred)),"r2":float(r2_score(yte,pred))}
def load_or_train_model(csv_path,model_path):
    d=load_data(csv_path); mp=Path(model_path)
    if mp.exists() and mp.stat().st_mtime>=Path(csv_path).stat().st_mtime:
        b=joblib.load(mp); return b["model"],b["metrics"]
    m,metrics=train_model(d); mp.parent.mkdir(parents=True,exist_ok=True)
    joblib.dump({"model":m,"metrics":metrics},mp); return m,metrics
def predict_score(model,values):
    row=pd.DataFrame([{k:values[k] for k in FEATURES}])
    return float(max(0,min(100,model.predict(row)[0])))
def performance_category(s):
    return "Excellent" if s>=85 else "Good" if s>=70 else "Needs improvement" if s>=50 else "At risk"
